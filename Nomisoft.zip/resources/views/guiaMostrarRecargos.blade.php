<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Mostrar Recargos</title>
    <style>
        h1{
            text-align: center;
        }
    </style>
</head>
<body>

    <img src="./img/logosi.jpg"/ style=" width: 60px; height: 75px;"> 

    <h1>Recargos</h1>

    <h3> Inoformacion sobre las horas extra.</h3>

    <p> Portero: Nombre del portero</p>

    <p>Ordinarios nocturnos: Son las horas normales nocturas. </p>

    <p>Diurno festivo: Son las horas normales diurnas festivas. </p>

    <p>Nocturno festivos: Son las horas normales nocturas festivas. </p>

    <p>Extra diurna: Son las horas extras diurnas ordinarias. </p>

    <p>Extra nocturna: Son las horas extra nocturas ordinarias. </p>

    <p>Extra diurna festiva : Son las horas extra diurnas festivas </p>

    <p>Extra nocturna festiva: Son las horas extra nocturas festivas. </p>

    <p>Total: Valor acumulados de todos los recargos</p>

     <center> <img src="./img/tablaRecargos.jpg"/ style=" width: 650px; height: 350px;"> </center>
    
</body>
</html>