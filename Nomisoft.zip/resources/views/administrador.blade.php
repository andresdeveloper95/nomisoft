@extends('layouts.layout')

<html>

<body>
    <h1>ADMINISTRADOR ÁNDRES</h1>
</body>
</html>
