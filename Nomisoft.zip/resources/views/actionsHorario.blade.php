<a href=""class="btn btn-warning btn-sm edit" role="button" data-toggle="modal" 
data-target="#editarHorario">Actualizar</a>

<a class="btn btn-danger btn-sm delete" role="button" data-toggle="modal" 
data-target="#deleteHorario1">Eliminar</a>

<!-- Tener en cuenta las palabras edit y delete que pusimos en cada enlace -->
