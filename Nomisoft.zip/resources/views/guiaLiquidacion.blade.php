<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Ayuda Liquidacion</title>
    <style>
        h1{
            text-align: center;
        }
    </style>
</head>
<body>

<img src="./img/logosi.jpg"/ style=" width: 60px; height: 75px;"> 

<h1>Generar Liquidación</h1>

<h3> 3.1.4 Generar liquidación </h3>

<p> En estas interfaz están las opciones necesarias para generar liquidación.</p>  

 <center> <img src="./img/genLiqui.jpg"/ style=" width: 550px; height: 250px;"> </center>

 <p>Para generar la liquidación  primero deberá selecciona el portero, luego la fecha de inicio y 
 la fecha de fin y dar click en el botón Generar Liquidación.</p>

 <center> <img src="./img/liquidacion.jpg"/ style=" width: 550px; height: 200px;"> </center>

 <p> Para mostrar los recargos deberá dar click en el botón Mostrar Recargos.</p>

 <h3>3.1.4.1 Mostrar liquidación </h3>

 <center> <img src="./img/mostrarRe.jpg"/ style=" width: 550px; height: 200px;"> </center>

 <p> Se desplegará un interfaz con los recargos generados.</p>

    </body>
</html>