<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>Nomisoft</title>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">

    <!-- Estas líneas son de los data table -->
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.21/css/dataTables.bootstrap4.min.css">

    <!-- SweetAlert-->
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

</head>
<body>
        <!--Aqui barra de navegación -->

    <div id="app">
      <nav class="navbar navbar-expand-md navbar-light bg-danger shadow-md">
            <div class="container">
                <img src="<?php echo e(asset('img/logo.jpg')); ?>" style=" width: 60px; height: 60px;">

                <a class=" navbar-brand text-white " style="font-size: 40px; " href="<?php echo e(url('/')); ?> ">   Universidad del Valle  </a>

               
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <!-- Left Side Of Navbar -->
                    <ul class="navbar-nav mr-auto">

                    </ul>

                    <!-- Right Side Of Navbar -->
                    <ul class="navbar-nav ml-auto">
                        <!-- Authentication Links -->
                        <?php if(auth()->guard()->guest()): ?>
                            <li class="nav-item">
                                <!--<a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>-->
                            </li>
                            <?php if(Route::has('register')): ?>
                                <li class="nav-item">
                                    <!--<a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>-->
                                </li>
                            <?php endif; ?>
                        <?php else: ?>

            

                    <!--validacion de usuarios por el rol secretaria -->
            <?php if( Auth::user()->rol=='S' ): ?>
            <!--(Route::has('homeSecretaria'))-->

           <div> 
                <li class="nav-item dropdown">     
                        <a class="dropdown-item" style="font-size: 20px;" href="<?php echo e(route('porteros.listar')); ?>">
                            <?php echo e(__('Porteros')); ?>

                        </a>
                </li>
            </div>
            <div>
                <a class="dropdown-item" style="font-size: 20px;" href="<?php echo e(route('turnos.listar')); ?>">
                        <?php echo e(__('Turnos')); ?>

                </a>
            </div>
            <div>
                <a class="dropdown-item" style="font-size: 20px;" href="">
                        <?php echo e(__('Liquidaciones')); ?>

                </a>
            </div>
                <a id="navbarDropdown" class="nav-link dropdown-toggle" style="font-size: 20px;" href="#" role="button" 
                    data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                    <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                </a>
            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                    onclick="event.preventDefault();
                    document.getElementById('logout-form').submit();">
                    <?php echo e(__('Cerrar Sesión')); ?>

                </a>

                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                <?php echo csrf_field(); ?>
                </form>
            </div>
        
                    <!--validacion de usuarios por el rol portero-->
            <li class="nav-item dropdown">
                <?php elseif(Auth::user()->rol==='P'): ?>

                <div>      
                        <a class="dropdown-item"  style="font-size: 20px;" href="">
                                <?php echo e(__('Consultar Horario')); ?>

                        </a>
                    </a>
                </div>

                    <a id="navbarDropdown" class="nav-link dropdown-toggle" style="font-size: 15px;" href="#" role="button" d
                    ata-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                        <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                    </a>

                    <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                        <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                            onclick="event.preventDefault();
                                            document.getElementById('logout-form').submit();">
                            <?php echo e(__('Cerrar Sesión')); ?>

                        </a>

                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                            <?php echo csrf_field(); ?>
                        </form>
                    </div>
            </li>

                    <!--validacion de usuarios por el rol administrador -->
                <?php else: ?>

                    <div> 
                    <li class="nav-item dropdown">     
                        <a class="dropdown-item" style="font-size: 20px;" href="<?php echo e(route('porteros.listar')); ?>">
                            <?php echo e(__('Porteros')); ?>

                        </a>
                    </li>
                </div>
                <div>
                
                    <a class="dropdown-item"  style="font-size: 20px;" href="<?php echo e(route('turnos.listar')); ?>">
                            <?php echo e(__('Turnos')); ?>

                    </a>
                </div>
                <div>
                    <a class="dropdown-item" style="font-size: 20px;" href="<?php echo e(route('horarios.listar')); ?>">
                            <?php echo e(__('Horarios')); ?>

                        </a>
                </div>
                <div>
                    <a class="dropdown-item" style="font-size: 20px;" href="">
                            <?php echo e(__('Liquidaciones')); ?>

                    </a>
                </div>
                    <a id="navbarDropdown" class="nav-link dropdown-toggle" style="font-size: 15px;" href="#" role="button" 
                    data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                        <?php echo e(Auth::user()->name); ?><span class="caret"></span>
                    </a>
                    
                    <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                        <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                            onclick="event.preventDefault();
                                            document.getElementById('logout-form').submit();">
                            <?php echo e(__('Cerrar Sesión')); ?>

                        </a>

                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                        <?php echo csrf_field(); ?>
                                    </form>
                                </div>
                            </li>
                            <?php endif; ?>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </nav>

    </div>

    <div>
        <main class="py-4">
           
        <!-- Aqui todo nuestro codigo, includes y otros -->
        <?php echo $__env->yieldContent('content'); ?>
        <?php echo $__env->yieldContent('content1'); ?>
        <?php echo $__env->yieldContent('content2'); ?>
        <?php echo $__env->make('crearPortero', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('eliminarPortero', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('actualizarPortero', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('crearTurno', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('eliminarTurno', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('actualizarTurno', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('crearHorario', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


        

        </main>
    </div>

    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
    <script src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js" defer></script>
    <script src="https://cdn.datatables.net/1.10.21/js/dataTables.bootstrap4.min.js" defer></script>

</body>

    <div class="card text-center">
        <div class="card-header"></div>
        <div class="card-body">
            <h5 class="card-title">Universidad del Valle</h5>
            <p class="card-text">La mejor para los mejores</p>
            <a href="#" class="btn btn-primary">Nomisoft Derechos Reservados AyJ S.A</a>
        </div>
    </div>
</html>

<!-- Método para mostrar los porteros -->

<script>
    $(function(){
        $('#tablePorteros').DataTable(
        {
            "serverSide":true,
            "ajax":"<?php echo e(url('api/porteros')); ?>",
            "columns":[
                {data:'id'},
                {data:'cedula'},
                {data:'name'},
                {data:'apellidos'},
                {data:'direccion'},
                {data:'telefono'},
                {data:'email'},
                {data:'btn'},
            ],
            "pageLength":8,
            language:{
                "search": "Buscar:",
            },
        });
    });
</script>

<!-- Método para crear los porteros -->

<script>
     $('#registro').click(function(){
        var ced=$('#_documento').val();
        var nom=$('#_nombres').val();
        var ape=$('#_apellidos').val();
        var dir=$('#_direccion').val();
        var tel=$('#_telefono').val();
        var cor=$('#email').val();
        

        var route="porteros";
        var token=$('#token').val();

        $.ajax({
            url:route,
            headers:{'X-CSRF-TOKEN': token},
            type:'POST',
            dataType:'json',
            data:{
                cedula:ced,
                name:nom,
                apellidos:ape,
                direccion:dir,
                telefono:tel,
                email:cor,
            },
        });
        $('#tablePorteros').DataTable().ajax.reload();
        
        swal("¡El portero se ha creado exitosamente!", {
                  icon: "success",
                });
    });
</script>

<!-- Método para el modal eliminar porteros-->

<script>
    $(function(){
        var table=$('#tablePorteros').DataTable();

        table.on('click','.delete',function(){

            swal({
              title: "¿Está seguro que desea eliminar portero?",
              icon: "warning",
              buttons: true,
              dangerMode: true,
            })
            .then((willDelete) => {
              if (willDelete) {

            $tr=$(this).closest('tr');
            if($($tr).hasClass('child')){
                $tr=$tr.prev('.parent');
            }
            var data=table.row($tr).data();
            //$('#idEliminar').val(data.id);
            //$('#deletePortero1').modal('show');
            var idEliminar=data.id;
            var route="/porteros/eliminar/"+idEliminar;

            $.ajax({
                    url:route,
                   // headers:{'X-CSRF-TOKEN': token},
                    type:'DELETE',
                    dataType:'json',
                    data:{
                    id:idEliminar,  
                    }
        });
        $('#tablePorteros').DataTable().ajax.reload();
         swal("¡El portero se ha eliminado correctamente!", {
                  icon: "success",
                });
              } 
            });


        });    
    });
</script>

<!-- Método para eliminar los porteros
<script>
    $("#elimina").click(function(){
        var idEliminar=$("#idEliminar").val();
        var token=$("#token").val();
        var route="/porteros/eliminar/"+idEliminar;
        $.ajax({
            url:route,
            headers:{'X-CSRF-TOKEN': token},
            type:'DELETE',
            dataType:'json',
            data:{
                id:idEliminar,  
            }
        });
        $('#tablePorteros').DataTable().ajax.reload();
    });
</script> -->


<!-- Método para mostrar el modal que actualizar porteros  -->
<script>
    $(function(){
        var table=$('#tablePorteros').DataTable();

        table.on('click','.edit',function(){
            $tr=$(this).closest('tr');
            if($($tr).hasClass('child')){
                $tr=$tr.prev('.parent');
            }
            var data=table.row($tr).data();
            $('#idActualizar').val(data.id);
            $('#nombres1').val(data.name);
            $('#apellidos1').val(data.apellidos);
            $('#direccion1').val(data.direccion);
            $('#telefono1').val(data.telefono);
            $('#correo1').val(data.email);

            $('#updatePortero').modal('show');  

        });    
    });
</script>


<!-- Método para actualizar porteros-->

<script>
    $('#registroUpdate').click(function(){

         swal({
          title: "¿Está seguro que desea actualizar portero?",
        
          icon: "info",
          buttons: true,
          dangerMode: true,
        })
        .then((willDelete) => {
          if (willDelete) {

        var idactualizar=$('#idActualizar').val();
        var nom=$('#nombres1').val();
        var ape=$('#apellidos1').val();
        var dir=$('#direccion1').val();
        var tel=$('#telefono1').val();
        var cor=$('#correo1').val();
        
        var route="/porteros/actualizar/"+idactualizar;

        var token=$('#token1').val();

        $.ajax({
            url:route,
            headers:{'X-CSRF-TOKEN': token},
            type:'PATCH',
            dataType:'json',
            data:{
                name:nom,
                apellidos:ape,
                direccion:dir,
                telefono:tel,
                email:cor,
            },
        });
        $('#tablePorteros').DataTable().ajax.reload();
         swal("¡El portero ha modificado correcatemente!", {
              icon: "success",
            });
          } 
        });  
    });
</script>

<!-- Método para mostrar los turnos -->

<script>
    $(function(){
        $('#tableTurnos').DataTable(
        {
            "serverSide":true,
            "ajax":"<?php echo e(url('api/turnos')); ?>",
            "columns":[
                {data:'id'},
                {data:'codigo'},
                {data:'horaInicio'},
                {data:'horaFin'},
                {data:'btn'},
            ],
            "pageLength":8,
            language:{
                "search": "Buscar:",
            },
        });
    });
</script>

<!-- Método para crear los turnos -->

<script>
     $('#registroTurno').click(function(){
        var cod=$('#_codigo').val();
        var ini=$('#_horaInicio').val();
        var fin=$('#_horaFin').val();

        var route="turnos";
        var token=$('#token').val();

        $.ajax({
            url:route,
            headers:{'X-CSRF-TOKEN': token},
            type:'POST',
            dataType:'json',
            data:{
                codigo:cod,
                horaInicio:ini,
                horaFin:fin,
            },
        });
        $('#tableTurnos').DataTable().ajax.reload();
         swal("¡El turno se ha creado correctamente!", {
                  icon: "success",
                });

    });
</script>

<!-- Método para el modal eliminar turno -->

<script>
    $(function(){
        //$("#deleteTurno").appendTo("body");
        var table=$('#tableTurnos').DataTable();

        table.on('click','.delete',function(){

            swal({
              title: "¿Está seguro que desea eliminar turno?",
              icon: "warning",
              buttons: true,
              dangerMode: true,
            })
            .then((willDelete) => {
              if (willDelete) {

            $tr=$(this).closest('tr');
            if($($tr).hasClass('child')){
                $tr=$tr.prev('.parent');
            }
            var data=table.row($tr).data();
            var idEliminar=data.id;
            //$('#idEliminarTurno').val(data.id);
            //$('#deleteTurno').modal('show');
            var route="/turnos/eliminar/"+idEliminar;

             $.ajax({
            url:route,
            headers:{'X-CSRF-TOKEN': token},
            type:'DELETE',
            dataType:'json',
            data:{
                id:idEliminar,  
            }
        });
        $('#tableTurnos').DataTable().ajax.reload();  

           swal("¡El portero se ha eliminado correctamente!", {
                  icon: "success",
                });
        }  
            }); 
        });    
    });
</script>

<!-- Método para eliminar los turnos 

<script>
    $("#eliminaTurno-btn").click(function(){
        var idEliminar=$("#idEliminarTurno").val();
        var token=$("#token").val();
        var route="/turnos/eliminar/"+idEliminar;
        $.ajax({
            url:route,
            headers:{'X-CSRF-TOKEN': token},
            type:'DELETE',
            dataType:'json',
            data:{
                id:idEliminar,  
            }
        });
        $('#tableTurnos').DataTable().ajax.reload();
    });
</script>   -->

<!-- Método para mostrar el modal que actualizar turno -->

<script>
    $(function(){
        //$("#uptadeTurno1").appendTo("body");
        var table=$('#tableTurnos').DataTable();
        

        table.on('click','.edit',function(){
            $tr=$(this).closest('tr');
            if($($tr).hasClass('child')){
                $tr=$tr.prev('.parent');
            }
            var data=table.row($tr).data();
            $('#idActualizarTurno').val(data.id);
            $('#inicio1').val(data.horaInicio);
            $('#fin1').val(data.horaFin);

            $('#updateTurno1').modal('show');  

        });    
    });
</script>

<script>
    //Esta línea es porque el modal estaba molestando al cerrar, quedaba atenuado
    $(function(){
     $("#updateTurno1").appendTo("body");
    });
</script>

<!-- Método para actualizar porteros turno-->

<script>
    $('#registroUpdateTurno').click(function(){

        swal({
          title: "¿Está seguro que desea actualizar turno?",
        
          icon: "info",
          buttons: true,
          dangerMode: true,
        })
        .then((willDelete) => {
          if (willDelete) {


        var idactualizar=$('#idActualizarTurno').val();
        var inicio=$('#inicio1').val();
        var fin=$('#fin1').val();
        
        var route="/turnos/actualizar/"+idactualizar;

        var token=$('#token3').val();

        $.ajax({
            url:route,
            headers:{'X-CSRF-TOKEN': token},
            type:'PATCH',
            dataType:'json',
            data:{
                horaInicio:inicio,
                horaFin:fin, 
            },
        });
        $('#tableTurnos').DataTable().ajax.reload();
        swal("¡El tuno se actualizó correcatemente!", {
              icon: "success",
            });
        }
         });
    });
</script>

<!-- Método para mostrar los horarios -->

<script>
    $(function(){
        $('#tableHorarios').DataTable(
        {
            "serverSide":true,
            "ajax":"<?php echo e(url('api/horarios')); ?>",
            "columns":[
                {data:'porteros'},
                {data:'sede'},
                {data:'mes'},
                {data:'primero'},
                {data:'segundo'},
                {data:'tercero'},
                {data:'cuarto'},
                {data:'quinto'},
                {data:'sexto'},
                {data:'septimo'},
                {data:'octavo'},
                {data:'noveno'},
                {data:'decimo'},
                {data:'once'},
                {data:'doce'},
                {data:'trece'},
                {data:'catorce'},
                {data:'quince'},
                {data:'dieciseis'},
                {data:'diecisiete'},
                {data:'diesocho'},
                {data:'diecinueve'},
                {data:'veinte'},
                {data:'veintiuno'},
                {data:'veintidos'},
                {data:'veintitres'},
                {data:'veinticuatro'},
                {data:'veinticinco'},
                {data:'veintiseis'},
                {data:'veintisiete'},
                {data:'veintiocho'},
                {data:'veintinueve'},
                {data:'treinta'},
                {data:'treintayuno'},
                {data:'btn'},
            ],
            "pageLength":8,
            language:{
                "search": "Buscar:",
            },
        });
    });
</script>


<!-- Método para crear los horarios -->

<script>
     $('#agregarHorario').click(function(){
        var porteros=$('#idporteros').val();
        var sede=$('#idsede').val();
        var mes=$('#idmes').val();        
        var primero=$('#idprimero').val();
        var segundo=$('#idsegundo').val();
        var tercero=$('#idtercero').val();
        var cuarto=$('#idcuarto').val();
        var quinto=$('#idquinto').val();
        var sexto=$('#idsexto').val();
        var septimo=$('#idseptimo').val();
        var octavo=$('#idoctavo').val();
        var noveno=$('#idnoveno').val();
        var decimo=$('#iddecimo').val();
        var once=$('#idonce').val();
        var doce=$('#iddoce').val();
        var trece=$('#idtrece').val();
        var catorce=$('#idcatorce').val();
        var quince=$('#idquince').val();
        var dieciseis=$('#iddieciseis').val();
        var diecisiete=$('#iddiecisiete').val();
        var diesocho=$('#iddiesocho').val();
        var diecinueve=$('#iddiecinueve').val();
        var veinte=$('#idveinte').val();
        var veintiuno=$('#idveintiuno').val();
        var veintidos=$('#idveintidos').val();
        var veintitres=$('#idveintitres').val();
        var veinticuatro=$('#idveinticuatro').val();
        var veinticinco=$('#idveinticinco').val();
        var veintiseis=$('#idveintiseis').val();
        var veintisiete=$('#idveintisiete').val();
        var veintiocho=$('#idveintiocho').val();
        var veintinueve=$('#idveintinueve').val();
        var treinta=$('#idtreinta').val();
        var treintayuno=$('#idtreintayuno').val();
        
        var route="horarios";
        var token=$('#tokenHorario').val();

        $.ajax({
            url:route,
            headers:{'X-CSRF-TOKEN': token},
            type:'POST',
            dataType:'json',
            data:{
                porteros:porteros,
                sede:sede,
                mes:mes,
                primero:primero,
                segundo:segundo,
                tercero:tercero,
                cuarto:cuarto,
                quinto:quinto,
                sexto:sexto,
                septimo:septimo,
                octavo:octavo,
                noveno:noveno,
                decimo:decimo,
                once:once,
                doce:doce,
                trece:trece,
                catorce:catorce,
                quince:quince,
                dieciseis:dieciseis,
                diecisiete:diecisiete,
                diesocho:diesocho,
                diecinueve:diecinueve,
                veinte:veinte,
                veintiuno:veintiuno,
                veintidos:veintidos,
                veintitres:veintitres,
                veinticuatro:veinticuatro,
                veinticinco:veinticinco,
                veintiseis:veintiseis,
                veintisiete:veintisiete,
                veintiocho:veintiocho,
                veintinueve:veintinueve,
                treinta:treinta,
                treintayuno:treintayuno,

                
                
            },
            /*
            success:function(respuesta){
                if(respuesta != 0){
                    if (respuesta  == "No se puede"){
                        alert('mayor de 30');
                    }
                    
                }
            },
            */
        });
        $('#tableHorarios').DataTable().ajax.reload();
        swal("¡El horario se ha creado correcatemente!", {
              icon: "success",
            });
    });
</script>

<!-- Método para el modal eliminar -->

<script>
    $(function(){
        $("#deleteHorario1").appendTo("body");
        var table=$('#tableHorarios').DataTable();

        table.on('click','.delete',function(){
            $tr=$(this).closest('tr');
            if($($tr).hasClass('child')){
                $tr=$tr.prev('.parent');
            }
            var data=table.row($tr).data();
            $('#idEliminarHorario').val(data.id);
            $('#deleteHorario').modal('show');     
        });    
    });
</script>

<!-- Método para eliminar los horarios -->

<script>
    $("#eliminaHorario-btn").click(function(){
        var idEliminar=$("#idEliminarHorario").val();
        var token=$("#token").val();
        var route="/horarios/eliminar/"+idEliminar;
        $.ajax({
            url:route,
            headers:{'X-CSRF-TOKEN': token},
            type:'DELETE',
            dataType:'json',
            data:{
                id:idEliminar,  
            }
        });
        $('#tableHorarios').DataTable().ajax.reload();
    });
</script>

<script>
    //Esta línea es porque el modal estaba molestando al cerrar, quedaba atenuado
    $(function(){
     $("#deleteHorario").appendTo("body");
    });
</script>


<script>
    //Esta línea es porque el modal estaba molestando al cerrar, quedaba atenuado
    $(function(){
     $("#createHorario").appendTo("body");
    });
</script>


<script>
$(document).ready(function() {
    $('#tablePorteros').DataTable();
} );
</script>

<script>
$(document).ready(function() {
    $('#tableTurnos').DataTable();
} );
</script>

<script>
$(document).ready(function() {
    $('#tableHorarios').DataTable();
} );
</script>



<script>
// Example starter JavaScript for disabling form submissions if there are invalid fields
    (function() {
    'use strict';
    window.addEventListener('load', function() {
        // Fetch all the forms we want to apply custom Bootstrap validation styles to
        var forms = document.getElementsByClassName('needs-validation');
        // Loop over them and prevent submission
        var validation = Array.prototype.filter.call(forms, function(form) {
        form.addEventListener('submit', function(event) {
            if (form.checkValidity() === false) {
            event.preventDefault();
            event.stopPropagation();
            }
            form.classList.add('was-validated');
        }, false);
        });
    }, false);
    })();
</script>







<?php /**PATH C:\laragon\www\proyectoF_Sin_Mensajes\resources\views/layouts/layout.blade.php ENDPATH**/ ?>