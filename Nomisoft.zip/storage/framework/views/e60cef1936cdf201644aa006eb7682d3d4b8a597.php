<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Ayuda Horarios </title>
    <style>
        h1{
            text-align: center;
        }
    </style>
</head>
<body>

<img src="./img/logosi.jpg"/ style=" width: 60px; height: 75px;"> 

<h1>Horarios Registrados</h1>

<h3> Informacion sobre los turnos </h3>
    <p> Turno A: 6 am - 2 pm </p>
    <p> Turno B: 2 pm - 10 pm </p>
    <p> Turno C: 10 pm - 6 am </p>
    <p> Turno D: 6 am - 6 pm </p>
    <p> Turno N: 6 pm - 6 am </p>
    <p> Turno E: 2 pm - 6 pm </p>
    <p> Turno A: 6 pm - 10pm </p>

 <p> Esta interfaz proporciona la opcion de consultar informacion sobre el nombre del portero, la sede a la que fue asignado, el mes y el turno asignado para cada dia.</p>

<center> <img src="./img/HorarioPortero.jpg"/ style=" width: 600px; height: 300px;"> </center>
 


 </body>
</html> <?php /**PATH C:\laragon\www\Nominal1.0\resources\views/guiaconsultarhorario.blade.php ENDPATH**/ ?>