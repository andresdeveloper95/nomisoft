<?php echo e($slot); ?>

<?php /**PATH C:\laragon\www\Nominal1.0\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>