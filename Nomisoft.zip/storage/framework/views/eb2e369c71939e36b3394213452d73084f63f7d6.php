<a href=""class="btn btn-warning btn-sm edit" role="button" data-toggle="modal" 
data-target="#editarPortero">Actualizar</a>

<a class="btn btn-danger btn-sm delete" role="button" data-toggle="modal" 
data-target="#deletePortero">Eliminar</a>

<!-- Tener en cuenta las palabras edit y delete que pusimos en cada enlace -->
<?php /**PATH C:\laragon\www\proyectoF\resources\views/actions.blade.php ENDPATH**/ ?>