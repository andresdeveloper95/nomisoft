<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Portero extends Model
{
    protected $fillable = ['cedula', 'name'];
}
